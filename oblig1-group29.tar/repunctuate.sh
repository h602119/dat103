#!/bin/bash

#Line gives better readability on the console
line="--------------------------"
location=""
echo $line
echo "Navigate to where your encrypted file is, type 'done' to finish, or 'ls' to list
"
#This section guides the user to the correct directory, starting from where this .sh file is located
while [[ $location != done ]]
do
echo "you are here:"
pwd
read location
if [[ $location == ls ]]
then
echo $line
#listing all child directorys
ls -d */
echo $line
elif [[ $location == done ]]
then
echo "Location selected"
else
cd $location
fi
done
echo $line
sleep 2
#This section helps the user to choose the file
echo "select a txt file from current directory to decrypt (do not include .txt)
"
#Listing all txt files
ls *.txt
echo $line
read file
file=$file.txt
echo $line
echo "decrypting $file"
echo $line
sleep 2
echo "Changing all hash values back to their original form"
echo $line
#Going line by line, if a line is punctuation it will be hashed, stored
#and changed in the txt file
number="1"
while read currentLine
do
if [[ -f $currentLine.txt ]]
then
decode=$(cat $currentLine.txt)
sed -i "$(($number))s/$currentLine/$decode/g" $file
fi
number=$((number+1))
done < $file
sleep 1
#re-assembling back to original form
echo $line
echo "Re-assembling"
sleep 1
#Removes all newlines
sed -zi 's/\n//g' $file
#All | -> newline
sed -zi 's/|/\n/g' $file
#All ~ -> space
sed -i 's/~/ /g' $file
#Adding suspension with simple loading
sleep 1
echo "*"
sleep 1
echo "**"
sleep 1
echo "***"
sleep 1
echo $line
echo "Process Complete"
echo $line
#program finished
