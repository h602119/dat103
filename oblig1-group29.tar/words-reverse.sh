#!/bin/bash

if [[ -n "$2" ]]; then #if the user puts more then 1 argument, the program crashes

printf "Only one argument is permitted" 1>&2
exit 2
fi

if [[ $1 == "--bypass" ]] || [[ ! -n "$1" ]]; then #if the user has nothing or --bypass the program will run

#line -> better readability in console
line="--------------------------"

echo $line
echo "Starting automated words-reverse"
echo $line


#creating a standard lorem.txt file to ensure this program always work.


./depunctuate.sh . <<< "Testing text lorem, ipsum dolor sit amet and so on..." #passes lorem.txt as the input for the depunctuate.sh file
	#depunctuate.sh complete...

cd temp #changing dir to place the reversed .txt file

newFile="reversedFile.txt"

echo $(tac ENC-file.txt) > $newFile #tac does the opposite of cat and since everything is on seperate lines, this will result in reversed text
sed -zi 's/[[:space:]]/\n/g' $newFile #any un-wanted spaces are swapped with newlines, all newlines are removed in de decoding process.

cd .. #going back to parent folder to execute the repunctuate 
./repunctuate.sh temp <<< "reversedFile.txt" #passes "loremReversed.txt" as the file to be decoded


#Getting the reversed txt file, and deleting the temp file.
cd temp
mv $newFile .. #move the reversed file to parent folder

cd .. #change directory back to parent folder

rm -r temp  #remove temporary folder with all hash lookups

echo "Temporary directory removed"
echo "New file with name '$newFile' can be found here"
pwd
echo $line

#Program finished


else #if the user dont put something else then nothing or --bypass the program chashes

printf "The input has to be eighter blanc or --bypass, otherwise the program will crash" 1>&2
exit 2

fi
