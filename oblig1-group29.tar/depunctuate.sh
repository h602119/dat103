line="--------------------------"
location=""

echo $line

echo "Navigate to where you want your files, type 'done' to finish, or 'ls' to list
"
#This section guides the user to the correct directory, starting from where this .sh file is located
while [[ $location != done ]]

do
echo "you are here:"
pwd
read location

if [[ $location == ls ]]
then
echo $line
ls -d */
echo $line

elif [[ $location == done ]]
then
echo "Location selected. Temporary directory created"

else
cd $location
fi

done

echo "$line"

#Creating a child directory for all new files called temp and waiting for it to complete
mkdir temp
sleep 2

#This section helps the user to choose the file
echo "select a txt file from current directory (do not include .txt)
"
ls *.txt
echo $line
read file
file=$file.txt
echo $line

echo "$(cat $file)" > ENC-$file

file=ENC-$file


echo "A file named $file has been created."
echo $line
sleep 2

mv $file temp
cd temp

#all newlines becomes |
sed -zi 's/\n/|/g' $file

#all spaces become ~
sed -i 's/[[:space:]]/~/g' $file

#since everything is connected a newline before and after every punctation
#makes sure every word and punctation is on a different line
sed -zi 's/[[:punct:]]/\n&\n/g' $file

echo "Changing all punctuations to their hash value"
echo $line

#Going line by line, if a line is punctuation it will be hashed, stored
#and changed in the txt file
number="1"

while read currentLine
do

if [[ $currentLine == [[:punct:]] ]]
then
hash=$(echo $currentLine|sha256sum|cut -d " " -f 1)
echo $currentLine > $hash.txt
sed -i "$(($number))s/$currentLine/$hash/g" $file
fi

number=$((number+1))
done < $file

#starting a easy load animation
sleep 1
echo "*"
sleep 1
echo "**"
sleep 1
echo "***"
sleep 1

echo $line
echo "Process Complete"
echo $line

#program finished
