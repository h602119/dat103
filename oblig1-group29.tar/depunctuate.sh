#!/bin/bash

if [[ $1 = "" ]]; then
>&2
exit 2
fi

cd $1 	#$1 is the first agument given by the user, changing directory to that...

#Creating a child directory for all new files called 'temp'
mkdir temp

#This section lets the user choose the file they want to depunctuate


read text #user input is saved as '$text'

echo "$text" > file.txt

file="file.txt" #the temp file that has been created

mv $file temp #moved to temp to generate new file for
cd temp
origFile=$file #the original file is stored


echo $( cat $file ) > ENC-$file
file=ENC-$file

mv $origFile .. #moves the original text file back to its original dir, a complicated process but makes it easier to decode later


#all newlines becomes |

sed -zi 's/\n/|/g' $file
#all spaces become ~

sed -i 's/[[:space:]]/~/g' $file
#since everything is now connected a newline before and after every punctation makes sure every word and punctation is on a different line.

	sed -zi 's/[[:punct:]]/\n&\n/g' $file

	number="1" #start on line one
while read currentLine
do
if [[ $currentLine == [[:punct:]] ]] #if the current line is punct then...
then
	hash=$(echo $currentLine|sha256sum|cut -d " " -f 1) #give it the hash value
	echo $currentLine > $hash.txt 	#store the original meaning inside the hashed txt file
	sed -i "$(($number))s/$currentLine/$hash/g" $file  #swap the punct on the current line with the hash value
fi
	number=$((number+1)) #increment number by one
done < $file


text=$( cat $file )
rm -r $file #det
cd ..
rm -r $origFile #deletes the original file created form the user input

echo "$text"

