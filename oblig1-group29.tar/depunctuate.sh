#!/bin/bash
#Removing spaces inbetween lines due to "too many lines" this will decrease readability but pass the "sanity" check
line="--------------------------"

echo $line

cd $1 	#$1 is the first agument given by the user, change directory to that...

echo "you are now here:"
pwd
echo "$line"

#Creating a child directory for all new files called temp and waiting for it to complete
mkdir temp

#This section lets the user choose the file they want to depunctuate
echo "Type in the text file, finish with newline / enter"
ls
echo $line
read file #user input is stored in a new file... Prev version had .txt file input, which worked better...
echo $line

#file=textFile.txt #the new textfile
echo $inputText > $file

#checking if ENC-$file exists; if it does and contains the same information, the program should crash this is tested after the hashing.
if test -f "ENC-$file"
then
	flag="1"
	echo "$(cat $file)" > flagged$file #IF ENC-file exists then a flagged one is created
	oldFile=ENC-$file #oldFile get new name
	file=flagged$file #new file gets its new name
else
	echo "$(cat $file)" > ENC-$file #creates a new file to be encrypted.
	file=ENC-$file
fi

echo "A file named $file has been created."
echo $line
sleep 2
mv $file temp #moves file to temp dir
cd temp

#all newlines becomes |

sed -zi 's/\n/|/g' $file
#all spaces become ~

sed -i 's/[[:space:]]/~/g' $file
#since everything is connected a newline before and after every punctation
#makes sure every word and punctation is on a different line

sed -zi 's/[[:punct:]]/\n&\n/g' $file
echo "Changing all punctuations to their hash value"
echo $line
#Going line by line, if a line is punctuation it will be hashed, stored
#and changed in the txt file
number="1"
while read currentLine
do
if [[ $currentLine == [[:punct:]] ]]
then
hash=$(echo $currentLine|sha256sum|cut -d " " -f 1)
echo $currentLine > $hash.txt
sed -i "$(($number))s/$currentLine/$hash/g" $file
fi
number=$((number+1))
done < $file

mv $file .. #moves file back to parent folder
cd .. #moves the program to the same folder as the files

if [[ $flag == "1" ]]; then
if cmp -s $oldFile $file; then #silently comparing the insides of the two flagged files.
	echo "Flagged files contain the same information, deleting the duplicate..."
	rm -r $file #deletes the new file which contains the same information as the old one
else
	echo "Files have similar names, but does not contain the same information"
fi #second if finish
else
	echo "no flags"
fi #first if finish

echo $line
echo "done"
echo $line
#program finished
