#the line is just to add stucture to the program
line="--------------------------"

echo $line
echo "Starting depunctuation in current folder, make sure a file named 'lorem.txt'"
echo "exists inside this folder"
echo $line
sleep 2
#Running depunctuate where 'done' selects current folder, and 'lorem' selects a file called lorem


./depunctuate.sh <<< "done
lorem"

cd temp

newFile="loremReversed"

echo $(tac ENC-lorem.txt) > $newFile.txt #tac does the opposite of cat and since everything is on a seperate line, this will result in reversed text
sed -zi 's/[[:space:]]/\n/g' $newFile.txt

#Change Directory to the parent directory so that we can repunctuate
cd ..

#gives instuctions to locate the reversed text so reassemble it
./repunctuate.sh <<< "temp
done 
$newFile"

cd temp #change directory to "temp" child
#Getting the reversed txt file, and deleting the temp file.
mv $newFile.txt .. #move the reversed file to parent folder

cd .. #change directory back to parent folder

rm -r temp  #remove temporary folder

echo "Temporery directory removed"
echo "New file with name '$newFile' can be found here"
pwd
echo $line
sleep 3

#Program finished

